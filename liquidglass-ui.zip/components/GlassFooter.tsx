"use client";
export const GlassFooter = () => (
  <footer className="w-full text-center py-4 bg-white/10 backdrop-blur-md border-t border-white/20 text-white text-sm">
    © 2025 LiquidGlass UI. All rights reserved.
  </footer>
);
