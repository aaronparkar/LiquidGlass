"use client";
export const GlassTooltip = ({ text }: { text: string }) => (
  <span className="relative group cursor-pointer">
    <span className="underline text-white">Hover me</span>
    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 hidden group-hover:block px-3 py-1 bg-white/20 backdrop-blur-sm text-sm text-white rounded shadow">
      {text}
    </div>
  </span>
);
