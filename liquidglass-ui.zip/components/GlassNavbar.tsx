"use client";
export const GlassNavbar = () => (
  <nav className="w-full py-4 px-8 fixed top-0 left-0 bg-white/10 backdrop-blur-md border-b border-white/20 z-50 flex justify-between items-center">
    <span className="text-white font-semibold text-lg">LiquidGlass</span>
    <div className="space-x-4">
      <a href="#" className="text-white/80 hover:text-white">Home</a>
      <a href="#" className="text-white/80 hover:text-white">About</a>
      <a href="#" className="text-white/80 hover:text-white">Contact</a>
    </div>
  </nav>
);
