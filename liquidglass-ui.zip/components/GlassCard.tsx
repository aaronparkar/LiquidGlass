"use client";
export const GlassCard = ({ children }: { children: React.ReactNode }) => (
  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl shadow-lg border border-white/10">
    {children}
  </div>
);
