"use client";
export const GlassSidebar = () => (
  <aside className="w-64 h-screen bg-white/10 backdrop-blur-md p-6 fixed top-0 left-0 border-r border-white/20">
    <nav className="space-y-4">
      <a href="#" className="block text-white/80 hover:text-white">Dashboard</a>
      <a href="#" className="block text-white/80 hover:text-white">Settings</a>
      <a href="#" className="block text-white/80 hover:text-white">Profile</a>
    </nav>
  </aside>
);
