"use client";
import { motion } from "framer-motion";

export const GlassModal = ({ isOpen, onClose, children }: { isOpen: boolean; onClose: () => void; children: React.ReactNode }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/10 backdrop-blur-lg p-6 rounded-2xl border border-white/20 text-white"
      >
        {children}
        <button onClick={onClose} className="mt-4 block ml-auto px-4 py-1 text-sm bg-white/20 hover:bg-white/30 rounded">
          Close
        </button>
      </motion.div>
    </div>
  );
};
