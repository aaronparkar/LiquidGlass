"use client";
export const GlassBadge = ({ label }: { label: string }) => (
  <span className="px-3 py-1 text-xs rounded-full bg-white/10 text-white backdrop-blur-md border border-white/20">
    {label}
  </span>
);
