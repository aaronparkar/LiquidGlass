"use client";
export const GlassButton = ({ label, onClick }: { label: string; onClick?: () => void }) => (
  <button
    onClick={onClick}
    className="px-6 py-2 bg-white/10 backdrop-blur-md text-white rounded-full hover:bg-white/20 transition border border-white/20"
  >
    {label}
  </button>
);
