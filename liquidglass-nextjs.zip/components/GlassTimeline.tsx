"use client";
export const GlassTimeline = () => (
  <div className="bg-glassWhite backdrop-blur-lg drop-shadow-glass p-4 rounded-xl border border-white/20 text-white">
    This is the <strong>GlassTimeline</strong> component.
  </div>
);
