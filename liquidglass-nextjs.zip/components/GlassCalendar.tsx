"use client";
export const GlassCalendar = () => (
  <div className="bg-glassWhite backdrop-blur-lg drop-shadow-glass p-4 rounded-xl border border-white/20 text-white">
    This is the <strong>GlassCalendar</strong> component.
  </div>
);
