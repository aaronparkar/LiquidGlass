"use client";
export const GlassTabs = () => (
  <div className="bg-glassWhite backdrop-blur-lg drop-shadow-glass p-4 rounded-xl border border-white/20 text-white">
    This is the <strong>GlassTabs</strong> component.
  </div>
);
