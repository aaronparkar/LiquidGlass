# LiquidGlass UI

30 fully responsive Apple-style frosted glass components using Next.js + Tailwind CSS.
Drop them into your project for immediate elegance.

MIT License.